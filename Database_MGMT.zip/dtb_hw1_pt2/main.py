import os.path
from dtb import database

# create database instance
current = database()

# display menu to user, handle input, and run menu options
def main():
    print("Database Menu")
    print()

    done = False
    while done == False:
        option = int(input("""
        1 - Create Database
        2 - Open Database
        3 - Close Database
        4 - Read Record (record number)
        5 - Display Record (ID)
        6 - Create Report of the First 10 Records
        7 - Update Record
        8 - Delete Record
        9 - Add Record
        10 - Quit

        Please choose from the options above: """))
        print()

        # runs create_database(input_name) if a valid csv is found for the input_name
        # and creates the database
        if option == 1:
            while True:
                created_file = input("Please enter the name of the file: \n")
                if not os.path.isfile(created_file + str(".csv")):
                    print(str(created_file) + ".csv not found.\n")
                else:
                    current.create_database(created_file)
                    break

        # runs open_database(input_name) if a database with the input name exists
        # and no other databases are currently open
        elif option == 2:
            if current.is_open():
                print("Cannot open a new database if a database is already open. Please close the current database.\n")
            else:
                database_to_open = input("Please enter the name of the database to open: \n")
                current.open_database(database_to_open)

        # runs close_database() and closes the currently open database
        elif option == 3:
            current.close_database()

        # runs read_record(record_number) if a record exists for the input record number
        # and displays it to the console
        elif option == 4:
            if current.is_open():
                record_num = input("Please enter the record number of the record you would like to display: \n")
                current.read_record(record_num)
                print("Record " + str(record_num) + ", ID: " + current.record["ID"] + "\t first_name: " + current.record["first_name"] + "\t last_name: " + current.record["last_name"]+"\t age: " + str(current.record["age"]) + "\t ticket_number: " + current.record["ticket_number"] + "\t fare: " + current.record["fare"] + "\t dop: " + current.record["dop"])
            else:
                print("There are no databases currently open to read records from.\n")

        # runs display_record(ID) if a record exists for the input ID
        # and displays it to the console
        elif option == 5:
            input_ID = int(input("Please enter the ID number of the person whose record you would like to display: \n"))
            current.display_record(input_ID)

        # runs create_report() and prints the first 10 records to the screen
        # formatted and sorted by ID number
        elif option == 6:
            current.create_report()

        # runs update record with an input ID that allows the user to choose
        # an attribute of a record to change (excluding the record ID)
        elif option == 7:
            input_ID = int(input("Please enter the ID of the record you would like to delete: \n"))
            current.update_record(input_ID)

        # calls delete_record(input_ID) for a valid input ID which uses
        # binary search to find a record and override it with a null entry
        elif option == 8:
            input_ID = int(input("Please enter the ID of the record you would like to delete: \n"))
            current.delete_record(input_ID)

        # calls the add record method that lets the user add a new record
        # in place of an empty one
        elif option == 9:
            # current.add_record()
            print()

        # closes the database and exits the program
        elif option == 10:
            if current.is_open():
                print("Please close the database that is currently open.\n")
            else:
                print("Quitting the program. Thank you for using the database manager. \n")
                done = True
                break
        else:
            print("Please input an option from 1-10\n")

# run the main method
if __name__ == "__main__":
    main()