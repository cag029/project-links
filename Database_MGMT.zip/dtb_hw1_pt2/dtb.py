import csv
import os.path

class database:

    # default constructor
    def __init__(self):
        self.num_records = 0
        self.record_size = 0
        self. file_stream = None
        self.file_pointer = None
        self.id_size = 5
        self.first_name_size = 15
        self.last_name_size = 20
        self.age_size = 5
        self.ticket_number_size = 20
        self.fare_size = 5
        self.dop_size = 15

    # create the database
    def create_database(self, file_name):
        # generate names for .csv, .data, and .config
        csv_filename = file_name + ".csv"
        text_filename = file_name + ".data"
        config_filename = file_name + ".config"

        # read input CSV and write .data and .config files
        with open(csv_filename, "r") as csv_file:
            data_list = list(csv.DictReader(csv_file, fieldnames=(
            'ID',
            'first_name',
            'last_name',
            'age',
            'ticket_number',
            'fare',
            'dop')))

        # fill every other entry with an empty record
        count = 0
        with open(text_filename, "w") as outfile:
            for dict in data_list:
                self.write_database(outfile, dict)
                empty_record = {"ID": "Null",
                                "first_name": "Null",
                                "last_name": "Null",
                                "age": "Null",
                                "ticket_number": "Null",
                                "fare": "Null",
                                "dop": "Null"}
                self.write_database(outfile, empty_record)
                count += 2

        # write .config
        self.num_records = count
        self.record_size = 86
        config_fileptr = open(config_filename, "w")
        config_fileptr.write("Database Information\n")
        config_fileptr.write("Number of records: {}\n".format(self.num_records))
        config_fileptr.write("Record size: {}\n".format(self.record_size))
        config_fileptr.close()

    # Function to write a record to the database file
    def write_database(self, file_stream, dict):
        file_stream.write("{:5.5}".format(dict["ID"], width=self.id_size))
        file_stream.write("{:15.15}".format(dict["first_name"], width=self.first_name_size))
        file_stream.write("{:20.20}".format(dict["last_name"], width=self.last_name_size))
        file_stream.write("{:5.5}".format(dict["age"], width=self.age_size))
        file_stream.write("{:20.20}".format(dict["ticket_number"], width=self.ticket_number_size))
        file_stream.write("{:5.5}".format(dict["fare"], width=self.fare_size))
        file_stream.write("{:15.15}".format(dict["dop"], width=self.dop_size))
        file_stream.write("\n")

    # open the database
    def open_database(self, database_name):
        if self.is_open():
            print("There is already a database open, please close it.\n")
        else:
            data_file = database_name + ".data"
            config_file = database_name + ".config"

        if not os.path.isfile(data_file):
            print(str(data_file) + " not found.\n")
        else:
            if not os.path.isfile(config_file):
                print(str(config_file) + " not found.\n")
            else:
                self.file_pointer = open(data_file, "r+")
                config_fileptr = open(config_file, "r")
                config_fileptr.readline()
                self.num_records = int(config_fileptr.readline().split(":")[1].strip())
                self.record_size = int(config_fileptr.readline().split(":")[1].strip())
                config_fileptr.close();

    # close the database that is currently open
    def close_database(self):
        if self.file_pointer:
            self.file_pointer.close()
            self.num_records = 0
            self.record_size = 0
            self.file_pointer = None
            self.file_stream = None
            print("database closed.\n")
        else:
            print("No database is currently open.\n")

    # check if the database is open
    def is_open(self):
        if self.file_pointer == None:
            return False
        else:
            return True

    # gets record information using a record number (index, i.e. 0 = line 1, 1 = line 2...)
    def read_record(self, record_number):
        self.flag = False
        ID = first_name = last_name = ticket_number = fare = dop = "None"

        if int(record_number) >= 0 and int(record_number) < self.num_records:
            self.file_pointer.seek(0, 0)
            self.file_pointer.seek(int(record_number) * self.record_size)
            line = self.file_pointer.readline().rstrip('\n')
            self.flag = True
        else:
            print("Please enter a record number between 0 and " + str(self.num_records) + "\n")
            self.flag = False
            self.record = dict({"ID": "Null",
                                "first_name": "Null",
                                "last_name": "Null",
                                "age": "Null",
                                "ticket_number": "Null",
                                "fare": "Null",
                                "dop": "Null"})
        if self.flag:
            ID = line[0:5]
            first_name = line[5:20]
            last_name = line[20:40]
            age = line[40:45]
            ticket_number = line[45:65]
            fare = line[65:70]
            dop = line[70:85]
            self.record = dict({"ID" : ID,
                                "first_name" : first_name,
                                "last_name" : last_name,
                                "age" : age,
                                "ticket_number" : ticket_number,
                                "fare" : fare,
                                "dop" : dop})


    # uses binary search to find a record given an input ID number
    def binary_search(self, input_ID):
        low = 0
        high = self.num_records - 1

        while low <= high:
            mid = (low + high) // 2
            byte = mid * self.record_size
            self.file_pointer.seek(byte)
            line = self.file_pointer.read(self.record_size).rstrip('\n')

            fields = [line[i:i+length].strip() for i, length in enumerate([5, 15, 20, 5, 20, 5, 15])]
            current_ID = fields[0] if fields[0].isdigit() else None

            if current_ID is not None:
                if int(current_ID) == int(input_ID):
                    return True, mid
                elif int(current_ID) < int(input_ID):
                    low = mid + 1
                else:
                    high = mid - 1
            else:
                next_line_index = (mid + 1) * self.record_size
                self.file_pointer.seek(next_line_index)
                next_line = self.file_pointer.read(self.record_size).rstrip('\n')
                fields = [next_line[i:i+length].strip() for i, length in enumerate([5, 15, 20, 5, 20, 5, 15])]
                current_ID = fields[0] if fields[0].isdigit() else None
                if current_ID is None:
                    high = mid - 1
                elif int(current_ID) == int(input_ID):
                    return True, mid + 1
                elif int(current_ID) < int(input_ID):
                    low = mid + 1
                else:
                    high = mid - 1

        return False, low

    # handles the binary search call for an input ID and prints the found record
    def display_record(self, input_ID):
        if not self.is_open():
            print("There are no databases currently open.\n")

        found, record_number = self.binary_search(input_ID)
        if not found:
            print("Record does not exist")
        else:
            self.read_record(record_number)
            print("ID: " + self.record["ID"] + "\t first_name: " + self.record["first_name"] + "\t last_name: " + self.record["last_name"]+"\t age: " + str(self.record["age"]) + "\t ticket_number: " + self.record["ticket_number"] + "\t fare: " + self.record["fare"] + "\t dop: " + self.record["dop"])

    # gathers the first 10 record ID's in order and displays their associated records
    def create_report(self):
        if not self.is_open():
            print("There are no databases currently open.\n")

        print("|    Report of First 10 Records:    |")
        print()
        print("{:<5} {:<15} {:<20} {:<5} {:<20} {:<5} {:<15}".format("ID", "First Name", "Last Name", "Age", "Ticket Number", "Fare", "DOP"))

        for record_number in range(min(10, self.num_records)):
            found, record_number = self.binary_search(record_number)
            if not found:
                print("Record is Empty")
            else:
                self.read_record(record_number)
                record = self.record
                print("{:<5} {:<15} {:<20} {:<5} {:<20} {:<5} {:<15}".format(
                    record["ID"], record["first_name"], record["last_name"],
                    record["age"], record["ticket_number"], record["fare"], record["dop"]))

    # uses binary search to find a record using the input ID and
    # allows the user to update any of the found records fields except the ID
    def update_record(self, input_ID):
        if not self.is_open():
            print("There are no databases currently open.\n")
            return

        found, record_number = self.binary_search(input_ID)
        if not found:
            print("Record does not exist")
        else:
            self.read_record(record_number)
            record = self.record

            print("Record found:")
            print("ID: " + record["ID"] + "\t first_name: " + record["first_name"] + "\t last_name: " + record["last_name"]+"\t age: " + str(record["age"]) + "\t ticket_number: " + record["ticket_number"] + "\t fare: " + record["fare"] + "\t dop: " + record["dop"])

            attribute = input("Enter the attribute you want to update (first_name, last_name, age, ticket_number, fare, dop): ").strip()
            if attribute in record:
                new_value = input("Enter the new value for {}: ".format(attribute)).strip()
                record[attribute] = new_value
                self.file_pointer.seek(record_number * self.record_size)
                self.write_database(self.file_pointer, record)  # Call the write_database method
                print("Record updated successfully")
            else:
                print("Invalid attribute")

    # uses binary search to find a record using the input ID and
    # overrides the entry with a blank entry (logically removing it)
    def delete_record(self, input_ID):
        if not self.is_open():
            print("There are no databases currently open.\n")
            return

        found, record_number = self.binary_search(input_ID)
        if not found:
            print("Record does not exist")
        else:
            empty_record = {"ID": "Null",
                            "first_name": "Null",
                            "last_name": "Null",
                            "age": "Null",
                            "ticket_number": "Null",
                            "fare": "Null",
                            "dop": "Null"}
            self.file_pointer.seek(record_number * self.record_size)
            self.write_database(self.file_pointer, empty_record)
            print("Record deleted successfully")


    # finds the first empty record in the database and allows
    # the user to add a new record in its place (NOT FUNCTIONAL)
    # If there are no empty records rewrite the file as double the size (NOT IMPLEMENTED)
    """ def add_record(self):
        if not self.is_open():
            print("There are no databases currently open.\n")
            return

        empty_record_found = False
        record_number = 0

        while record_number < self.num_records:
            self.read_record(record_number)
            record = self.record
            if record["ID"] == "Null":
                empty_record_found = True
                break
            record_number += 1

        if not empty_record_found:
            print("No empty slot available to add a new record.")
            return

        print("Adding a new record to slot", record_number)

        new_record = {}
        new_record["ID"] = input("Enter ID: ").strip()
        new_record["first_name"] = input("Enter First Name: ").strip()
        new_record["last_name"] = input("Enter Last Name: ").strip()
        new_record["age"] = input("Enter Age: ").strip()
        new_record["ticket_number"] = input("Enter Ticket Number: ").strip()
        new_record["fare"] = input("Enter Fare: ").strip()
        new_record["dop"] = input("Enter Date of Purchase: ").strip()

        self.file_pointer.seek(record_number * self.record_size)
        self.write_database(self.file_pointer, new_record)
        print("Record added successfully") """
