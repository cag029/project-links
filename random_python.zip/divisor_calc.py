import math

def get_divisors(n):
    divisors = []
    sqrt = int(math.sqrt(n))
    for i in range(1, sqrt + 1):
        if n % i == 0:
            divisors.append(i);
            if i != n // i:
                divisors.append(n // i)
    return divisors

def main():
    test_cases = int(input())
    numbers = []

    for i in range(test_cases):
        n = int(input())
        numbers.append(n)

    for i in numbers:
        d = get_divisors(i)
        print(d)

if __name__ == "__main__":
    main()