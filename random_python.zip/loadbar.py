import time
import sys

def print_bar(x, y):
    #print("progress: [" + "*" * y + "-" * (x - y) + "]", end="\r")
    print("", end="\r")
    print("progress: [" + "*" * y + "-" * (x - y) + "]", end="")
    #print("*" * y + "-" * (x - y), end="")
    #print("]", end="\r")

def countdown(x):
    y = 1

    while y <= x:
        print_bar(x, y)
        # print(y)
        y += 1
        time.sleep(1)
    print("\ncompleted")

def main():
    sec = int(input("seconds: "))

    countdown(sec)

if __name__ == "__main__":
    main()