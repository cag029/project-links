# merge sorting method
def merge_sort(list):
    # return the list if one or less strings
    if len(list) <= 1:
        return list

    # vars for each list half
    mid = len(list) // 2
    left = list[:mid]
    right = list[mid:]

    # run merge sort on each half recursively
    left = merge_sort(left)
    right = merge_sort(right)

    # use helper to sort and merge list
    return merge(left, right)

# merge sort helper
def merge(left, right):
    results = []
    l_index = 0
    r_index = 0

    # run through each list half
    # check if the word in the left is <= the word in the right
    # append appropriate string to results[]
    while l_index < len(left) and r_index < len(right):
        if left[l_index] <= right[r_index]:
            results.append(left[l_index])
            l_index += 1
        else:
            results.append(right[r_index])
            r_index += 1

    # add remaining words if length of left != length of right
    results.extend(left[l_index:])
    results.extend(right[r_index:])

    # return sorted merged list
    return results

def main():
    test_cases = int(input())
    lists = []

    # for each test case get the number of words
    for i in range(test_cases):
        n = int(input())

        # store the words for each test case
        strings = [input().strip() for j in range(n)]

        # sort using merge sort and add to lists[]
        sorted_strings_list = merge_sort(strings)
        lists.append(sorted_strings_list)

    # print each list of strings
    for sorted_strings_list in lists:
        for string in sorted_strings_list:
            print(string)

if __name__ == "__main__":
    main()