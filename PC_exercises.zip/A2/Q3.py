# returns the max number of candies any 1 student can get
def get_max_candies(box_contents, num_people):
    # puts the number of candies in descending order
    box_contents.sort(reverse=True)

    # if there are one or 0 people to be given candies
    # the box with the most candies or 0 is returned
    # if the number of people exceeds the number of boxes 0 is returned
    if num_people >= len(box_contents):
        return 0
    elif(num_people == 1):
        return max(box_contents)
    elif(num_people == 0):
        return 0
    else:
        # the logic is if there i people, and the number of candies are sorted
        # in descending order, then spot 0 + i - 1 would correspond to the most candies
        # that can be given out if each person can only take candy from one box
        return box_contents[0 + num_people - 1]

        # I also tried using this logic:
        # each person is given a candy while the box that corresponds to
        # the most candies that can be given if each person only gets a candy from
        # one box is not empty. The logic is that if there are 3 people, then the
        # box at spot box_contents[2] will contain the most candies that can be given out
        # since it is sorted in descending order
        # for i in range(num_people):
        #     while(box_contents[0 + num_people - 1] > 0):
        #         box_contents[0 + num_people - 1] -= 1
        #         candies += 1

def main():
    # get test cases
    test_cases = int(input())
    results = []

    # for each test case get n number of boxes and k number of friends
    # map each input number of candies to the nth box
    for i in range(test_cases):
        num_boxes, num_people = map(int, input().split())
        box_contents = list(map(int, input().split()))

        result = get_max_candies(box_contents, num_people)
        results.append(result)

    for i in results:
        print(i)

if __name__ == "__main__":
    main()