# quick sorting method
def quick_sort(list):
    # if list is <= 1 word return the list
    if len(list) <= 1:
        return list

    # set pivot to the last element of the list
    pivot = list.pop()

    # make a list of words greater than and less than the pivot
    greater = []
    lesser = []

    # for each word in the list chek against the pivot
    # append words > or < to the appropriate list
    for i in list:
        if i > pivot:
            greater.append(i)
        else:
            lesser.append(i)

    # run quick sort recursively using the list of words
    # lesser and greater than the pivot and the pivot itself
    return quick_sort(lesser) + [pivot] + quick_sort(greater)

def main():
    test_cases = int(input())
    lists = []

    # for each test case get the number of words
    for i in range(test_cases):
        n = int(input())

        # store the words for each test case
        strings = [input().strip() for j in range(n)]

        # sort using quick sort and add to lists[]
        sorted_strings_list = quick_sort(strings)
        lists.append(sorted_strings_list)

    # print each list of strings
    for sorted_strings_list in lists:
        for string in sorted_strings_list:
            print(string)

if __name__ == "__main__":
    main()