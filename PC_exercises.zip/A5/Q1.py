# uses sieve of ertaosthenes to find prime nums
def sieve(limit):
    #list of bools representing whteher index is prime or not
    primes = [True] * (limit + 1)
    primes[0] = primes[1] = False
    p = 2 # starts at first prime 2
    # loop until p^2 is greater than the limit (tried many for SPOJ, 10000, 100000, 200000, 1000000)
    while p * p <= limit:
        if primes[p]:
            for i in range(p * p, limit + 1, p):
                primes[i] = False
        p += 1
    return [i for i in range(limit + 1) if primes[i]] # returns list of prime numbers

# precomputes  primes for efficiency
def precompute_twin_primes(limit):
    primes = sieve(limit)
    twin_primes = []
    # iterates through list of primes and if the next prime differs by 2 the pair is stored
    for i in range(len(primes) - 1):
        if primes[i] + 2 == primes[i + 1]:
            twin_primes.append((primes[i], primes[i + 1]))
    return twin_primes

def main():
    t = int(input())
    test_cases = []

    for _ in range(t):
        x = int(input())
        if(x != 0):
            test_cases.append(x)

    limit = 250000  # Max limit needed for finding primes
    twin_primes = precompute_twin_primes(limit)

    for x in test_cases:
        print(*twin_primes[x - 1])

if __name__ == "__main__":
    main()