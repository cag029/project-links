def maximum_milk(N, cows):
    cows.sort(key=lambda x: x[1])  # sort cows based on deadline

    total_milk = 0
    milked_times = [False] * (max(c[1] for c in cows) + 1)  # list to track milking times

    for cow in cows:
        milked_time = cow[1] # time available to milk current cow
        # check if any cows have already been milked at this time slot or if the slot is unavailable
        while milked_time > 0 and milked_times[milked_time]:
            milked_time -= 1 # move to previous time slot if unavailable
        # if theres time, milk the cow and mark time slot as used
        if milked_time > 0:
            total_milk += cow[0] # add milk produced to total
            milked_times[milked_time] = True # mark time slot as used

    return total_milk

def main():
    N = int(input())  # number of cows
    cows = []  # list to store cows as tuples
    for _ in range(N):
        g, d = map(int, input().split())  # for each cow get milk produced and time available for milking
        cows.append((g, d))

    print(maximum_milk(N, cows))  # should output max gallons farmer can obtain

if __name__ == "__main__":
    main()