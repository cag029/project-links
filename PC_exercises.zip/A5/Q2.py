# determines the maximum products that can be produced given a budget and num. of robots
def max_products(T, test_cases):
    results = []
    # for each test case get num. of robots and available budget
    for _ in range(T):
        N, M = test_cases[_][0]
        robots = test_cases[_][1]

        # sort robots based on improvement/cost ratio
        robots.sort(key=lambda x: (x[0] / x[1], -x[1]))

        max_products = 0
        current_budget = M

        # check if the budget is 0 or if you cannot upgrade any robots
        if current_budget == 0 or robots[0][1] > current_budget:
            results.append(0)
            continue

        # for each robot determine the maximum number of products that can be produced
        for p, m in robots:
            # invest remaining budget into current robot and determine how many products can be produced
            max_additional_products = min(current_budget // m, (M - max_products * m) // m)
            max_products += min(max_additional_products, N - max_products)
            current_budget -= max_additional_products * m

            # exit if budget becomes insufficient
            if current_budget < robots[0][1]:
                break

        results.append(max_products)

    return results

def main():
    T = int(input())
    test_cases = []
    for _ in range(T):
        N, M = map(int, input().split())
        robots = [tuple(map(int, input().split())) for _ in range(N)]
        test_cases.append(((N, M), robots))

    results = max_products(T, test_cases)
    for result in results:
        print(result)

if __name__ == "__main__":
    main()
