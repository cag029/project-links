import sys
from collections import defaultdict


class Tree:
    def __init__(self):
        self.nodes = defaultdict(list)

    def add_edge(self, a, b, c):
        self.nodes[a].append((b, c))
        self.nodes[b].append((a, c))


def dfs(tree, node, parent, distances, shortest, longest):
    for neighbor, distance in tree.nodes[node]:
        if neighbor != parent:
            distances[neighbor] = distances[node] + distance
            shortest[neighbor] = min(shortest[neighbor], shortest[node], distance)
            longest[neighbor] = max(longest[neighbor], longest[node], distance)
            dfs(tree, neighbor, node, distances, shortest, longest)


def process_queries(tree, queries):
    for d, e in queries:
        distances = [0] * (len(tree.nodes) + 1)
        shortest = [sys.maxsize] * (len(tree.nodes) + 1)
        longest = [0] * (len(tree.nodes) + 1)

        dfs(tree, d, 0, distances, shortest, longest)
        print(shortest[e], longest[e])


def main():
    N = int(input())
    tree = Tree()
    for _ in range(N - 1):
        a, b, c = map(int, input().split())
        tree.add_edge(a, b, c)

    K = int(input())
    queries = [tuple(map(int, input().split())) for _ in range(K)]

    process_queries(tree, queries)


if __name__ == "__main__":
    main()
