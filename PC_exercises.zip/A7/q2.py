import sys


def dfs(graph, visited, start):
    visited[start] = True
    for neighbor in graph[start]:
        if not visited[neighbor]:
            dfs(graph, visited, neighbor)


def is_connected(graph, n):
    visited = [False] * (n + 1)
    dfs(graph, visited, 1)
    return all(visited[1:])


t = int(sys.stdin.readline())
for _ in range(t):
    n, m = map(int, sys.stdin.readline().split())
    graph = [[] for _ in range(n + 1)]
    for _ in range(m):
        a, b = map(int, sys.stdin.readline().split())
        graph[a].append(b)
        graph[b].append(a)

    if is_connected(graph, n):
        sys.stdout.write("YES\n")
    else:
        sys.stdout.write("NO\n")