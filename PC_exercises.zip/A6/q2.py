# determine minimum amount of money for k kilos of apples for n friends
def minimum_amount(n, k, prices):
    # list to store minimum amount per kilo vals (and 0kg requires $0)
    dp = [float('inf')] * (k + 1)
    dp[0] = 0

    # iterate through each kilo and each possible packet size to see if its available
    for i in range(1, k + 1):
        for j in range(1, min(i, k) + 1):
            if prices[j - 1] != -1:
                # update dp with minimum of current value, sum of price of current packet size, and minimum amount needed to buy i - j kilo
                dp[i] = min(dp[i], dp[i - j] + prices[j - 1])

    # return minimum amount of money for k kilos
    return dp[k] if dp[k] != float('inf') else -1

def main():
    test_cases = int(input().strip())

    for _ in range(test_cases):
        # map friends and kilos
        n, k = map(int, input().strip().split())
        # map prices of apple packets
        prices = list(map(int, input().strip().split()))

        result = minimum_amount(n, k, prices)
        print(result)

if __name__ == "__main__":
    main()