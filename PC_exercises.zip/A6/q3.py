def max_different_coins(n, coins):
    coins.sort()  # sort coins (ascending)
    max_coins = 0
    remaining_amount = sum(coins)
    types_obtained = set()

    # exit if not able to withdraw
    if remaining_amount < 1:
        return 0

    # simulate withdrawal process
    while remaining_amount > 0:
        max_coin = 0
        for coin in coins:
            if coin <= remaining_amount:
                max_coin = coin
            else:
                break
        types_obtained.add(max_coin)
        remaining_amount -= max_coin

    return len(types_obtained)

def main():
    T = int(input())
    for case in range(1, T + 1):
        # num of coin types
        n = int(input())
        # map coin vals
        coins = list(map(int, input().split()))
        result = max_different_coins(n, coins)
        print(f"Case #{case}: {result}")

if __name__ == "__main__":
    main()