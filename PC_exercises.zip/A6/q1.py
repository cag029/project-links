# find the smallest integer M with product of digits equal to N
def smallest_integer_with_product(n):
    # if N is 0 return 10 since its the smallest int whose digits product is 0
    if n == 0:
        return 10

    #if N is 1 return 1 because its the smallest int whos product is 1
    if n == 1:
        return 1

    # store M digits
    digits = []

    # greedily construct M by getting largest prime factors
    for i in range(9, 1, -1):
        while n % i == 0:
            digits.append(i)
            n //= i

    # if a prime factor > 9 return -1
    if n > 1:
        return -1

    # sort digits (ascending)
    digits.sort()

    # if the list is empty N is single digit
    if not digits:
        return n

    # construct M from the digits
    m = int(''.join(map(str, digits)))

    return m

def main():
    T = int(input())
    test_cases = [int(input()) for _ in range(T)]

    for n in test_cases:
        print(smallest_integer_with_product(n))

if __name__ == "__main__":
    main()