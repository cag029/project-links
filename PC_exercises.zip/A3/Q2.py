import sys

# computes prefix function vals for kmp search using the pattern.
# the prefix function vals represent the length of the longest proper
# prefix that is also a suffix of the pattern.
def compute_prefix(pattern):
    m = len(pattern)
    pfv = [0] * m # array of prefix function vals init=0,...,0
    k = 0 # length of previous proper prefix

    # iterate through pattern
    for i in range(1, m):
        # update k based on current char copmparison
        while k > 0 and pattern[k] != pattern[i]:
            k = pfv[k - 1]
        # increment k if characters match
        if pattern[k] == pattern[i]:
            k += 1
        # store k (calculated prefix function val) for current position
        pfv[i] = k
    return pfv

# returns a list of indices where the pattern is found in the string
# by efficiently iterating through the string, "skipping" portions according
# to the previously calculated array of prefix function values
def kmp(string, pattern, pfv):
    n = len(string)
    m = len(pattern)
    q = 0
    occurrences = []

    # iterate through string
    for i in range(n):
        # update current state in the pattern using current char comparison
        while q > 0 and pattern[q] != string[i]:
            q = pfv[q - 1]
        if pattern[q] == string[i]:
            q += 1
        # if the current state matches, pattern occurence is found and stored
        if q == m:
            occurrences.append(i - m + 2)
            q = pfv[q - 1]
    return occurrences

def main():
    # get the number of test cases and the string and pattern for each test case
    test_cases = []
    num_tc = int(sys.stdin.readline().strip())
    patterns = {}

    for i in range(num_tc):
        A, B = sys.stdin.readline().strip().split()
        if B not in patterns:
            patterns[B] = compute_prefix(B)
        test_cases.append((A, B, patterns[B]))

    # for each test case call the kmp search method and append results
    results = []
    for A, B, pfv in test_cases:
        occurrences = kmp(A, B, pfv)
        if occurrences:
            results.append((len(occurrences), occurrences))
        else:
            results.append(("Not Found",))

    # print the results to the console
    for result in results:
        if result[0] != "Not Found":
            print(result[0])
            print(*result[1])
        else:
            print(result[0])
        print()

if __name__ == "__main__":
    main()