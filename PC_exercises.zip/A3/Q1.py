# uses the string and pattern to count the number of occurrences
# by iterating through the string and using pythons std. String find() with the pattern
def find_pattern(string, pattern):
    occurrences = []
    start_index = 0
    while True:
        index = string.find(pattern, start_index)
        if index == -1:
            break
        occurrences.append(index + 1)
        start_index = index + 1
    return occurrences

def main():
    # get the number of test cases and the string and pattern for each test case
    test_cases = []
    num_tc = int(input().strip())
    for i in range(num_tc):
        A, B = input().strip().split()
        test_cases.append((A, B))

    # for each test case call find pattern and append results
    results = []
    for A, B in test_cases:
        occurrences = find_pattern(A, B)
        if occurrences:
            results.append((len(occurrences), occurrences))
        else:
            results.append(("Not Found",))

    # print the results to the console
    for result in results:
        if result[0] != "Not Found":
            print(result[0])
            print(*result[1])
        else:
            print(result[0])
        print()

if __name__ == "__main__":
    main()