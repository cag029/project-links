# stores the to do list as a set and checks for each of the queries if there is a
# substring already in the to do list, if so it prints YES otherwise it prints NO
def serve_ada():
    Q = int(input())
    todo_list = set()
    queries = []

    for i in range(Q):
        query = input().strip()
        queries.append(query)

    results = []
    for query in queries:
        t, s = query.split()
        if int(t) == 0:
            # Insertion query
            todo_list.add(s)
        else:
            # Question query
            if any(substring in s for substring in todo_list):
                results.append("YES")
            else:
                results.append("NO")

    # Output all the results
    for result in results:
        print(result)

serve_ada()
