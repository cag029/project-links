//----------------------------------------------
// Purpose: Starter code for homework 3 - you should use this code 
// to read in your files instead of starting from scratch!
//----------------------------------------------

#include "password.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <limits>
using namespace std;

//print the title for the application
void printTitle()
{
    cout << "+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n" 
         << "|P a s s - M a c h i n e|-|9 0 0 0|\n" 
         << "+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n\n";
}

//print the menu
void printMenu()
{
    cout << "Please pick a choice from the list below: \n\n" 
         << "(1) Search recursively for two passwords and print all the passwords between them\n"  
         << "(2) Search recursively by password\n" 
         << "(3) Search recursively by hash\n"  
         << "(4) Compare linear and binary searches for a password\n"
         << "(5) Iterative binary search for password\n" 
         << "(6) Exit the program\n\n";
}

// PROVIDED
bool readFile(string filename, vector <Password> & list)
{
    string password;
    string rank;
    string hash;

    ifstream din;
    din.open(filename);
    
    if(din.fail())
    {
        cout << "Error in opening file.\n";
        return 0;
    }
    
    while(getline(din, password, ','))
    {
        getline(din, rank, ',');
        getline(din, hash);
        Password temp (password,stoi(rank),hash);
        list.push_back(temp);
    }
    
    din.close();
    
    return 1;
}

// PROVIDED
bool readFile_given_hashes(string filename, vector <string> & list)
{
    string hash;

    ifstream din;
    din.open(filename);
    
    if(din.fail())
    {
        cout << "Error in opening file.\n";
        return 0;
    }
    
    while(getline(din,hash))
    {
        list.push_back(hash);
    }
    
    return 1;
}

//recursive binary search using strings for plaintext passwords
int binarySearchRecursive(vector <Password> list, string target, int beg, int end, int & iterations)
{
    int mid = (beg + end) / 2;
    
    if(beg > end)
    {
        return -1;
    }
    
    if(list[mid].getPlainText() == target)
    {
        return mid;
    }
    else if(list[mid].getPlainText() < target)
    {
        iterations++;
        return binarySearchRecursive(list, target, mid + 1, end, iterations);
    }
    else
    {
        iterations++;
        return binarySearchRecursive(list, target, beg, mid - 1, iterations);    
    }
}

//recursive binary search using integers for hash values
int binarySearchRecursiveInt(vector <Password> list, int target, int beg, int end)
{
    int mid = (beg + end) / 2;
    
    if(beg > end)
    {
        return -1;
    }
    
    int hashMid = stoi(list[mid].getHash(), 0, 16);
    
    if(hashMid == target)
    {
        return mid;
    }
    else if(hashMid < target)
    {
        return binarySearchRecursiveInt(list, target, mid + 1, end);
    }
    else
    {
        return binarySearchRecursiveInt(list, target, beg, mid - 1);    
    }
}

//iterative binary search
int binarySearchIterative(vector<Password> list, string target, int beg, int end)
{
    while(beg <= end)
    {
        int mid = (beg + end) / 2;
        
        if(list[mid].getPlainText() == target)
        {
            return mid;
        }
        else if(list[mid].getPlainText() < target)
        {
            beg = mid + 1;
        }
        else
        {
            end = mid - 1;
        }
    }
    
    return -1;
}

//linear search
int linearSearch(vector<Password> list, string target, int & iterations)
{
    iterations = 0;
    
    for(size_t x = 0; x <= list.size() - 1; x++)
    {
        if(list[x].getPlainText() == target)
        {
            return x;
        }
        else
        {
            iterations++;
        }
    }
    
    return -1;
}

//search for two passwords and print the passwords that are between them
void searchRange(vector <Password> list)
{
    string pass1, pass2;
    int iterations = 0;
    
    cout << "Please enter the first password:\n";
    cin >> pass1;
    cout << "\nPlease enter the second password:\n";
    cin >> pass2;
    cout << "\n";
    
    int firstPassPos = binarySearchRecursive(list, pass1, 0, list.size() - 1, iterations);
    int secondPassPos = binarySearchRecursive(list, pass2, 0, list.size() - 1, iterations);
    
    if(firstPassPos == -1 || secondPassPos == -1)
    {
        cout << "One or more passwords were not found\n";
    }
    else 
    {
        cout << "Printing passwords between \"" << list[firstPassPos].getPlainText() << "\" and \"" << pass2 << "\":\n";
        
        int start = min(firstPassPos, secondPassPos);
        int end = max(firstPassPos, secondPassPos);
        
        for(int x = start; x <= end; x++)
        {
            cout << list[x].getPlainText() << "\n";
        }
    }
    
    cout << "\n";
    printMenu();
}

//use recursive binary search to find a password
void searchPass(vector <Password> list)
{
    string passToFind;
    int iterations = 0;
    
    cout << "Please enter the password you would like to find:\n";
    cin >> passToFind;
    
    int passPos = binarySearchRecursive(list, passToFind, 0, list.size() - 1, iterations);
    
    if(passPos == -1)
    {
        cout << "\nThe password you are looking for is not in the list\n";
    }
    else
    {
      cout << "\n" << passToFind << " was found at index " << passPos << "\n";
      cout << "Its rank is " << list[passPos].getRank() << " and its hash value is " << list[passPos].getHash() << "\n";
    }
    
    cout << "\n";
    printMenu();
}

//use iterative binary search to find a password
void searchPassIterative(vector <Password> list)
{
    string passToFind;
    
    cout << "Please enter the password you would like to find:\n";
    cin >> passToFind; 
    
    try
    {
        int passPos = binarySearchIterative(list, passToFind, 0, list.size() - 1);
    
        if(passPos == -1)
        {
            cout << "\nThe password you are looking for is not in the list\n";
        }
        else
        {
          cout << "\n" << passToFind << " was found at index " << passPos << "\n";
          cout << "Its rank is " << list[passPos].getRank() << " and its hash value is " << list[passPos].getHash() << "\n";
        }
    }
    catch(const invalid_argument & e)
    {
        cout << "\nError - invalid input\n\n";
        printMenu();
        return;
    }
    catch(const out_of_range & e)
    {
        cout << "\nError - invalid input\n\n";
        printMenu();
        return;
    }
    
    cout << "\n";
    printMenu();
}

//view available hashes to search and use binary recursive search to find 
//out if the hash value searched for is in the list
void searchHash(vector <Password> list, vector <string> & hashList)
{
    string hashToFindString;
    int hashToFind, hashPos;
    
    cout << "List of hashes available to search from:\n";
    
    for(size_t x = 0; x < hashList.size(); x++)
    {
        cout << hashList[x] << "\n";
    }
    
    cout << "\nPlease enter the hash value you would like to find:\n";
    cin >> hashToFindString;
    
    try
    {
        hashToFind = stoi(hashToFindString, 0, 16);
    }
    catch(const invalid_argument & e)
    {
        cout << "\nError - invalid input\n\n";
        printMenu();
        return;
    }
    catch(const out_of_range & e)
    {
        cout << "\nError - invalid input\n\n";
        printMenu();
        return;
    }
    
    hashPos = binarySearchRecursiveInt(list, hashToFind, 0, list.size() - 1);
    
    if(hashPos == -1)
    {
        cout << "\nThe hash value you are looking for is not in the list\n";
    }
    else
    {
      cout << "\n" << list[hashPos].getHash() << " was found at index " << hashPos << "\n";
      cout << "Its plaintext is " << list[hashPos].getPlainText() << " and its rank is " << list[hashPos].getRank() << "\n";
    }
    
    cout << "\n";
    printMenu();
}

//search for a password using a linear search and a recursive binary search 
//and compare the number of iterations each method used
void searchAndCompare(vector<Password> list)
{
    string passToFind;
    int recIterations = 0;
    int linIterations = 0;
    
    cout << "Please enter the password you would like to use to compare the search methods: \n";
    cin >> passToFind;
    cout << "\n";
    
    int recursivePos = binarySearchRecursive(list, passToFind, 0, list.size() - 1, recIterations);
    int linearPos = linearSearch(list, passToFind, linIterations);

    if (recursivePos == -1 || linearPos == -1) 
    {
        cout << "\nThe password you are looking for is not in the list\n";
    } 
    else 
    {
        if (recursivePos != -1) 
        {
            cout << "Recursive search: " << passToFind << " was found at index " << recursivePos << " after " << recIterations << " iterations\n";
        }

        if (linearPos != -1) 
        {
            cout << "Iterative search: " << passToFind << " was found at index " << linearPos << " after " << linIterations << " iterations\n";
        }
    }
    
    cout << "\n";
    printMenu();
}

//----------------------------------------------
int main()
{
    //vector for hash sorted file to store has values
    vector<Password> hashValues;
    //vector for password sorted file to store plaintext passwords
    vector<Password> plainText;
    //vector for hashes to search for
    vector<string> givenHashes;
    
    readFile("sorted_hash_indexed_list.txt", hashValues);
    readFile("sorted_password_indexed_list.txt", plainText);
    readFile_given_hashes("hashes_to_search.txt", givenHashes);

    // ADD YOUR MENU, USER CHOICE, AND IMPLEMENT MENU OPTIONS HERE
    int choice;
    bool run = true;
    
    printTitle();
    printMenu();
    
    do 
    {
        cin >> choice;
        if(cin.fail())
        {
            cout << "\nError: Invalid input. Please enter a valid number.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "\n";
            continue;
        }
        cout << "\n";
        
        switch (choice) 
        {
            case 1:
                searchRange(plainText);
                break;
            case 2:
                searchPass(plainText);
                break;
            case 3:
                searchHash(hashValues, givenHashes);
                break;
            case 4:
                searchAndCompare(plainText);
                break;
            case 5:
                searchPassIterative(plainText);
                break;
            case 6:
                cout << "Quitting the program\n\n";
                run = false;
                break;
            default:
                cout << "Invalid input, please enter a number from 1-8\n";
        }
    } while (run);
    
    return 0;
}


