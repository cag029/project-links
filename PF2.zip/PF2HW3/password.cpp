#include "password.h"

//constructor/destructor/copy
Password::Password()
{
    rank = 0;
    plainText = "NULL";
    hash = "NULL";
}

Password::Password(const string PLAINTEXT, const int RANK, const string HASH)
{
    plainText = PLAINTEXT;
    rank = RANK;
    hash = HASH;
}

Password::~Password()
{
    
}

//setters
void Password::setPlainText(const string PLAINTEXT) 
{
    plainText = PLAINTEXT;
}

void Password::setRank(const int RANK) 
{
    rank = RANK;
}

void Password::setHash(const string HASH) 
{
    hash = HASH;
}

//getters
string Password::getPlainText() const 
{
    return plainText;
}

int Password::getRank() const 
{
    return rank;
}

string Password::getHash() const 
{
    return hash;
}

//print
void Password::print() const
{
    
}
