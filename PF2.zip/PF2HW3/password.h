#ifndef PASSWORD_H 
#define PASSWORD_H

#include <iostream>
using namespace std;

class Password
{
    public:
        //constructors/copy/destructor
        Password();
        Password(const string PLAINTEXT, const int RANK, const string HASH);
        //Password(const restaurantNode & copy);
        ~Password();
        
        //get.
        string getPlainText() const;
        int getRank() const;
        string getHash() const;
        
        //set.
        void setPlainText(const string PLAINTEXT);
        void setRank(const int RANK);
        void setHash(const string HASH);
        
        void print() const;
        
    private:
        string plainText, hash;
        int rank;
};

#endif
