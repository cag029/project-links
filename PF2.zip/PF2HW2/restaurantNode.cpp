#include "restaurantNode.h"

//constructors/copy/destructor
restaurantNode::restaurantNode()
{
    rName = "NULL";
    rating = 0.0;
    mName = "NULL";
    mType = "NULL";
    price = 0.0;
    next = NULL;
    prev = NULL;
}
restaurantNode::restaurantNode(const string RNAME, const float RATING, const string MNAME, const string MTYPE, const float PRICE, restaurantNode * N, restaurantNode * P)
{
    rName = RNAME;
    rating = RATING;
    mName = MNAME;
    mType = MTYPE;
    price = PRICE;
    next = N;
    prev = P;
}
restaurantNode::restaurantNode(const restaurantNode & copy)
{
    rName = copy.rName;
    rating = copy.rating;
    mName = copy.mName;
    mType = copy.mType;
    price = copy.price;
    next = copy.next;
    prev = copy.prev;
}
restaurantNode::~restaurantNode()
{
    
}

//get.
string restaurantNode::getRestaurantName() const
{
    return rName;
}
float restaurantNode::getRating() const
{
    return rating;
}
string restaurantNode::getMealName() const
{
    return mName;
}
string restaurantNode::getMealType() const
{
    return mType;
}
float restaurantNode::getPrice() const
{
    return price;
}
restaurantNode * restaurantNode::getNext()
{
    return next;
}
restaurantNode * restaurantNode::getPrev()
{
    return prev;
}

//set.
void restaurantNode::setRestaurantName(const string RNAME)
{
    rName = RNAME;
}
void restaurantNode::setRating(const float RATING)
{
    rating = RATING;
}
void restaurantNode::setMealName(const string MNAME)
{
    mName = MNAME;
}
void restaurantNode::setMealType(const string MTYPE)
{
    mType = MTYPE;
}
void restaurantNode::setPrice(const float PRICE)
{
    price = PRICE;
}
void restaurantNode::setNext(restaurantNode * N)
{
    next = N;
}
void restaurantNode::setPrev(restaurantNode * P)
{
    prev = P;
}

//print
void restaurantNode::print() const
{
    cout << "Restaurant Name: " << rName << "\n"
         << "Rating: " << rating << "/10\n"
         << "Meal Name: " << mName << "\n"
         << "Meal Type: " << mType << "\n"
         << "Price: $" << price << "\n\n";
}