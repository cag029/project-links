#include "restaurantList.h"
#include <string>

void printTitle()
{
    cout << "+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n" 
         << "|M e a l|-|S t o r e r|-|5 0 0 0|\n" 
         << "+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+\n\n";
}

void printMenu()
{
    cout << "Please pick a choice from the list below: \n\n" 
         << "(1) Display the list of restaurants\n"  
         << "(2) Display the list of restaurants in reverse\n" 
         << "(3) Add a restaurant and meal to the list\n"  
         << "(4) Find the most expensive meal in the list\n" 
         << "    and display the restaurant information for\n"  
         << "    the restaurant that is selling the meal\n"  
         << "(5) Change a meals price using the meals name\n" 
         << "(6) Clear the list of restaurants and exit the program\n\n";
}

void menuOption1(restaurantList & listToPrint)
{
    cout << "Displaying the list of restaurants in descending order by rating:\n\n";
    listToPrint.print();
    printMenu();
}

void menuOption2(restaurantList & listToPrint)
{
    cout << "Displaying the list of restaurants in ascending order by rating:\n\n";
    listToPrint.printReverse();
    printMenu();
}

void menuOption3(restaurantList & listToAddTo)
{
    string rName, ratingString, mName, mType, priceString, tempClear;
    float rating, price;
    
    bool validInput = false;
    bool validInput2 = false;
    
    getline(cin, tempClear);
    cout << "Please enter the name for the restaurant that you would like to add, followed by a period:\n";
    getline(cin, rName, '.');
    cout << "\n";
    getline(cin, tempClear);
    
    while(!validInput)
    {
        cout << "Please enter the rating of the restaurant (0.0-10.0)\n";
        getline(cin, ratingString);
        
        try
        {
            rating = stof(ratingString);
            if(rating <= 0 || rating > 10)
            {
                cout << "Error - please input a number between 0.0-10.0\n";
            }
            else
            {
                validInput = true;
            }
        } 
        catch(const invalid_argument & e)
        {
            cout << "Error - please input a valid number between 0.0-10.0\n";
        }
        
        cout << "\n";
    }
    
    cout << "Please enter the meals name, followed by a period:\n";
    getline(cin, mName, '.');
    cout << "\n";
    
    getline(cin, tempClear);
    cout << "Please enter a meal type (appetizer, entree, dessert, snack, etc.), followed by a period:\n";
    getline(cin, mType, '.');
    cout << "\n";
    getline(cin, tempClear);
    
    while(!validInput2)
    {
        cout << "Please enter the price of the meal:\n";
        getline(cin, priceString);
        try
        {
            price = stof(priceString);
            if(price <= 0)
            {
                cout << "Error - please input a number between greater than 0\n";
            }
            else
            {
                validInput2 = true;
            }
        }
        catch(const invalid_argument & e)
        {
            cout << "Error - please input a valid number greater than 0\n";
        }
        
        cout << "\n";
    }
    
    listToAddTo.addMeal(rName, rating, mName, mType, price);
    cout << "Your meal \"" << mName << "\" at " << rName << " has been added to the list\n\n";
    
    printMenu();
}

void menuOption4(restaurantList & listToPrint)
{
    cout << "Highest price meal/restaurant information: \n";
    restaurantNode tempHighPriceNode = restaurantNode(*listToPrint.highestPrice());
    tempHighPriceNode.print();
    
    printMenu();
}

void menuOption5(restaurantList & listTemp)
{
    string mealToChange, priceToChangeToString, tempClear;
    float priceToChangeTo;
    
    getline(cin, tempClear);
    cout << "Please enter the name of the meal that you would like\n"
         << "to change the price of, followed by a period:\n";
    getline(cin, mealToChange, '.');
    cout << "\n";
    
    getline(cin,tempClear);
    cout << "Please enter the price you would like to change to:\n";
    getline(cin, priceToChangeToString);
    cout << "\n";
    
    priceToChangeTo = stof(priceToChangeToString);
    listTemp.changePrice(mealToChange, priceToChangeTo);
    
    cout << "Your meal price has been changed, print the menu to see these changes\n\n";
    
    printMenu();
}


int main()
{
    restaurantList listOfRestaurants1;
    int choice;
    bool run = true;
    
    printTitle();
    printMenu();
    
    do 
    {
        cin >> choice;
        cout << "\n";
        
        switch (choice) 
        {
            case 1:
                menuOption1(listOfRestaurants1);
                break;
            case 2:
                menuOption2(listOfRestaurants1);
                break;
            case 3:
                menuOption3(listOfRestaurants1);
                break;
            case 4:
                menuOption4(listOfRestaurants1);
                break;
            case 5:
                menuOption5(listOfRestaurants1);
                break;
            case 6:
                cout << "\nQuitting the program\n\n";
                run = false;
                break;
            default:
                cout << "Invalid input, please enter a number from 1-8\n";
        }
    } while (run);
    
    return 0;
}