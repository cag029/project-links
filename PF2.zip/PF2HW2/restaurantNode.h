#ifndef RESTAURANTNODE_H 
#define RESTAURANTNODE_H

#include <iostream>
using namespace std;

class restaurantNode
{
    public:
        //constructors/copy/destructor
        restaurantNode();
        restaurantNode(const string RNAME, const float RATING, const string MNAME, const string MTYPE, const float PRICE, restaurantNode * N, restaurantNode * P);
        restaurantNode(const restaurantNode & copy);
        ~restaurantNode();
        
        //get.
        string getRestaurantName() const;
        float getRating() const;
        string getMealName() const;
        string getMealType() const;
        float getPrice() const;
        restaurantNode * getNext();
        restaurantNode * getPrev();
        
        //set.
        void setRestaurantName(const string RNAME);
        void setRating(const float RATING);
        void setMealName(const string MNAME);
        void setMealType(const string MTYPE);
        void setPrice(const float PRICE);
        void setNext(restaurantNode * N);
        void setPrev(restaurantNode * P);
        
        void print() const;
        
    private:
        string rName, mName, mType;
        float rating, price;
        restaurantNode * next;
        restaurantNode * prev;
};

#endif