#include "restaurantList.h"

//constructor/copy/destructor
restaurantList::restaurantList()
{
    head = NULL;
    tail = NULL;
}

restaurantList::restaurantList(const restaurantList & copy)
{
    head = NULL;
    tail = NULL;
    
    restaurantNode * copyNode = copy.head;
    
    while(copyNode != NULL)
    {
        addMeal(copyNode->getRestaurantName(), copyNode->getRating(), copyNode->getMealName(), copyNode->getMealType(), copyNode->getPrice());
        copyNode = copyNode->getNext();
    }
}

restaurantList::~restaurantList()
{
    restaurantNode * current = head;
    
    while(current != NULL)
    {
        restaurantNode * temp = current;
        current = current->getNext();
        delete temp;
    }
    
    cout << "List was cleared.\n";
}

//Insert a restaurantNode into the list sorted by highest rating to lowest rating
void restaurantList::addMeal(const string RNAME, const float RATING, const string MNAME, const string MTYPE, const float PRICE)
{
    restaurantNode * current = head;
    restaurantNode * previous = NULL;
    
    while(current != NULL && current->getRating() > RATING)
    {
        previous = current;
        current = current->getNext();
    }
    
    restaurantNode * temp = new restaurantNode(RNAME, RATING, MNAME, MTYPE, PRICE, current, previous);
    //temp->setNext(current);
    //temp->setPrev(previous);
    
    if(current == head)
    {
        head = temp;
    }
    else
    {
        previous->setNext(temp);
    }
    if(current != NULL)
    {
        current->setPrev(temp);
    }
    else
    {
        tail = temp;
    }
}

//find the restaurantNode with the highest meal price
restaurantNode * restaurantList::highestPrice() const
{
    restaurantNode * temp = head;
    float highestPrice = temp->getPrice();
    restaurantNode * final = head;
    
    while(temp != NULL)
    {
        if(temp->getPrice() >= highestPrice)
        {
            highestPrice = temp->getPrice();
            final = temp;
        }
        temp = temp->getNext();
    }

    return final;
}

//find a restaurantNode and change the meal price
void restaurantList::changePrice(const string findMealName, float changePriceTo)
{
    restaurantNode * temp = head;
    //float priceToChange = temp->getPrice();
    
    while(temp != NULL)
    {
        if(temp->getMealName() == findMealName)
        {
            temp->setPrice(changePriceTo);
            break;
        }
        temp = temp->getNext();
    }
}

//print list (rating highest to lowest)
void restaurantList::print() const
{
    restaurantNode * temp = head;
    
    while(temp != NULL)
    {
        temp->print();
        temp = temp->getNext();
    }
}

//print list in reverse order (rating lowest to highest)
void restaurantList::printReverse() const
{
    restaurantNode * temp = tail;
    
    while(temp != NULL)
    {
        temp->print();
        temp = temp->getPrev();
    }
}

