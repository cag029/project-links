#ifndef RESTAURANTLIST_H 
#define RESTAURANTLIST_H

#include "restaurantNode.h"

class restaurantList
{
    public:
        restaurantList();
        restaurantList(const restaurantList & copy);
        ~restaurantList();
        
        void addMeal(const string RNAME, const float RATING, const string MNAME, const string MTYPE, const float PRICE);
        restaurantNode * highestPrice() const;
        void changePrice(const string findMealName, float priceToChange);
        void print() const;
        void printReverse() const;
        
    private:
        restaurantNode * head;
        restaurantNode * tail;
};

#endif