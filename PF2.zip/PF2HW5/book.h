#ifndef BOOK_H
#define BOOK_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <ctime>

using namespace std;

class Book
{
public:
    //const./copy/dest.
    Book();
    Book(const int YEAR, const string TITLE, const string ALNAME, const string AFNAME, const string GENRE, const float RATING);
	Book(const Book & copy);
    ~Book();
    
    //set.
    void setYear(const int YEAR);
    void setTitle(const string TITLE);
    void setALName(const string ALNAME);
    void setAFName(const string AFNAME);
    void setGenre(const string GENRE);
    void setRating(const float RATING);
    
    //get.
    int getYear() const;
    string getTitle() const;
    string getALName() const;
    string getAFName() const;
    string getGenre() const;
    float getRating() const;
    
    //print/misc.
    void print() const;
    
private:
    int year;
    string title, alName, afName, genre;
    float rating;
    
};

#endif
