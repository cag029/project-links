#include "book.h"

using namespace std;

//read in file
bool readFile(string filename, vector <Book> & list)
{
    string yearStr, title, alName, afName, genre, ratingStr;

    ifstream din;
    din.open(filename);
    
    if(din.fail())
    {
        cout << "\nError - opening file failed\n";
        return 0;
    }
    
    while(getline(din, yearStr, ','))
    {
        getline(din, title, ',');
        getline(din, alName, ',');
        getline(din, afName, ',');
        getline(din, genre, ',');
        getline(din, ratingStr, ',');
        try
        {
            Book temp (stoi(yearStr), title, alName, afName, genre, stof(ratingStr));
            list.push_back(temp);
        }
        catch(const invalid_argument & e)
        {
            cout << "\n";
        }
    }
    
    din.close();
    
    return true;
}

//write file
void writeFile(string fileName, vector <Book> & list)
{
    ofstream dout;
    dout.open(fileName);
    
    for(size_t x = 0; x < list.size(); x++)
    {
        if(list[x].getYear() != 0)
        {
            dout << list[x].getYear() << "," 
                 << list[x].getTitle() << ","
                 << list[x].getALName() << ","
                 << list[x].getAFName() << ","
                 << list[x].getGenre() << ","
                 << list[x].getRating() << ",";
        }
        if(list[x + 1].getYear() != 0)
        {
            dout << "\n";
        }
    }
    
    dout.close();
}

//insertion sort descending order by year (5,4,3,...)
void insertionSort(vector <Book> & list, int low, int high)
{
    for(int unsorted = low + 1; unsorted < high; unsorted++)
    {
        Book temp = list[unsorted];
        int pos = unsorted;
        
        while(pos > 0 && list[pos - 1].getYear() < temp.getYear())
        {
            list[pos] = list[pos - 1];
            pos--;
        }
        
        list[pos] = temp;
    }
}

//selection sort ascending order by title (a..z)
void selectionSort(vector<Book> & list, int low, int high)
{
    for(int last = high; last > low; last--)
    {
        int max = low;
        
        for(int x = low + 1; x <= last; x++)
        {
            if(list[x].getTitle() > list[max].getTitle())
            {
                max = x;
            }
        }
        
        Book temp = list[max];
        list[max] = list[last];
        list[last] = temp;
    }
}

//merge sort ascending order by authors last name (a..z)
void mergeSortCopy(vector<Book> & list, vector<Book> & copyList, int low, int high)
{
    int range = high - low + 1;
    
    if (range > 1)
    {
        int mid = (low + high) / 2;
        mergeSortCopy(list, copyList, low, mid);
        mergeSortCopy(list, copyList, mid + 1, high);
        
        int x = low;
        int y = mid + 1;
        int i = 0;
        
        while (x <= mid && y <= high)
        {
            if (list[x].getALName() < list[y].getALName())
            {
                copyList[i++] = list[x++];
            }
            else
            {
                copyList[i++] = list[y++];
            }
        }
    
        while (x <= mid)
        {
            copyList[i++] = list[x++];
        }
        
        while (y <= high)
        {
            copyList[i++] = list[y++];
        }
        
        for (i = 0; i < range; i++)
        {
            list[low + i] = copyList[i];
        }
    }
}

//merge sort ascending order by authors last name (a..z)
void mergeSort(vector<Book> & list, int low, int high)
{
   int range = high - low + 1;
   
   if (range > 1)
   {
      vector <Book> copyList;
      copyList.resize(range);
      mergeSortCopy(list, copyList, low, high);
   }
}

//median of 3 values
int median(int a, int b, int c)
{
   if (a < b)
   {
      if (a < c)
      {
         if (b < c)
         {
            return b;
         }
         else
         {
            return c;
         }
      }
      else
      {
         return a;
      }
   }
   else
   {
      if (a < c)
      {
         return a;
      }
      else
      {
         if (b < c)
         {
            return c;
         }
         else
         {
            return b;
         }
      }
   }
}

//partition for use with quicksort()
void partition(vector<Book> & list, int low, int high, int & mid)
{
    
    #define HIGH
    #ifdef HIGH
        float pivot = list[high].getRating();
    #endif
    
    #ifdef LOW
        float pivot = list[low].getRating();
        list[low] = list[high];
        list[high].setRating(pivot);
    #endif
    
    #ifdef MID
        mid = (low + high) / 2;
        float pivot = list[mid].getRating();
        list[mid] = list[high];
        list[high].setRating(pivot);
    #endif
    
    #ifdef MEDIAN
        mid = (low + high) / 2;
        float pivot = median(list[low].getRating(), list[mid].getRating(), list[high].getRating());
        
        if (list[low].getRating() == pivot)
        {
            list[low] = list[high];
            list[high].setRating(pivot);
        }
        else if (list[mid].getRating() == pivot)
        {
            list[mid] = list[high];
            list[high].setRating(pivot);
        }
    #endif
    
    int left = low;
    int right = high;
    
    while (left < right)
    {
        while ((left < right) && (list[left].getRating() < pivot)) 
        {
        left++;
        }
        while ((left < right) && (list[right].getRating() >= pivot)) 
        {
        right--;
        }
        
        float temp = list[left].getRating();
        list[left] = list[right];
        list[right].setRating(temp);
    }
    
    mid = left;
    list[high] = list[mid];
    list[mid].setRating(pivot);
}

//quicksort ascending order by rating (1,2,3,...)
void quickSort(vector <Book> & list, int low, int high)
{
   if (low < high)
   {
      int mid = 0;
      partition(list, low, high, mid);

      quickSort(list, low, mid - 1);
      quickSort(list, mid + 1, high);
   }
}

//user menu option 1
void menuOption1(vector <Book> & list)
{
    clock_t start = clock();
                
    insertionSort(list, 0, list.size());
                
    clock_t end = clock();
    double runtime = (end - start) / double(CLOCKS_PER_SEC);
    cout << "Run time for insertionSort(): " << runtime << " seconds\n\n";
                
    writeFile("insertionSort.csv", list);
}

//user menu option 2
void menuOption2(vector <Book> & list)
{
    clock_t start = clock();
                
    selectionSort(list, 0, list.size() - 1);
                
    clock_t end = clock();
    double runtime = (end - start) / double(CLOCKS_PER_SEC);
    cout << "Run time for selectionSort(): " << runtime << " seconds\n\n";
                
    writeFile("selectionSort.csv", list);
}

//user menu option 3
void menuOption3(vector <Book> & list)
{
    clock_t start = clock();
                
    mergeSort(list, 0, list.size() - 1);
                
    clock_t end = clock();
    double runtime = (end - start) / double(CLOCKS_PER_SEC);
    cout << "Run time for mergeSort(): " << runtime << " seconds\n\n";
                
    writeFile("mergeSort.csv", list);
}

//user menu option 4
void menuOption4(vector <Book> & list)
{
    clock_t start = clock();
                
    quickSort(list, 0, list.size());
                
    clock_t end = clock();
    double runtime = (end - start) / double(CLOCKS_PER_SEC);
    cout << "Run time for quickSort(): " << runtime << " seconds\n\n";
                
    writeFile("quickSort.csv", list);    
}

int main()
{
    int choice;
    string choiceSTR;
    bool run = true;
    vector <Book> booksList;
    
    readFile("books.csv", booksList);
    
    do 
    {
        cout << "Please choose an option below:\n" 
             << "(1) - Insertion Sort by Year (5,4,3,...)\n"
             << "(2) - Selection Sort by Title (a..z)\n"
             << "(3) - Merge Sort by Author Last Name (a..z)\n"
             << "(4) - Quick Sort by Rating (1,2,3,...)\n"
             << "(5) - Quit the Program\n\n";
             
        getline(cin, choiceSTR);
        try
        {
            choice = stoi(choiceSTR);
        }
        catch(const invalid_argument & e)
        {
            cout << "\nError - invalid input\n";
        }
        
        
        cout << "\n";
        
        switch (choice) 
        {
            case 1:
                menuOption1(booksList);
                break;
            case 2:
                menuOption2(booksList);
                break;
            case 3:
                menuOption3(booksList);
                break;
            case 4:
                menuOption4(booksList);
                break;
            case 5:
                cout << "Quitting the program...\n\n";
                run = false;
                break;
            default:
                cout << "Invalid input - please enter a number from 1-5\n\n";
        }
    } while (run);
         
    return 0;
}
