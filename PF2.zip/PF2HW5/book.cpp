#include "book.h"

//const./copy/dest.
Book::Book()
{
    year = 0;
    title = "NULL";
    alName = "NULL";
    afName = "NULL";
    genre = "NULL";
    rating = 0.0;
}
Book::Book(const int YEAR, const string TITLE, const string ALNAME, const string AFNAME, const string GENRE, const float RATING)
{
    year = YEAR;
    title = TITLE;
    alName = ALNAME;
    afName = AFNAME;
    genre = GENRE;
    rating = RATING;
}
Book::Book(const Book & copy)
{
    year = copy.year; 
    title = copy.title;
    alName = copy.alName;
    afName = copy.afName;
    genre = copy.genre;
    rating = copy.rating;
}
Book::~Book()
{
    
}

//set.
void Book::setYear(const int YEAR)
{
    year = YEAR;
}
void Book::setTitle(const string TITLE)
{
    title = TITLE;
}
void Book::setALName(const string ALNAME)
{
    alName = ALNAME;
}
void Book::setAFName(const string AFNAME)
{
    afName = AFNAME;
}
void Book::setGenre(const string GENRE)
{
    genre = GENRE;
}
void Book::setRating(const float RATING)
{
    rating = RATING;
}

//get.
int Book::getYear() const
{
    return year;
}
string Book::getTitle() const
{
    return title;
}
string Book::getALName() const
{
    return alName;
}
string Book::getAFName() const
{
    return afName;
}
string Book::getGenre() const
{
    return genre;
}
float Book::getRating() const
{
    return rating;
}

//print/misc.
void Book::print() const
{
    cout  << year << "\n" << title 
         << "\n" << alName << "\n" << afName
         << "\n" << genre << "\n" << rating << "\n\n";
}
