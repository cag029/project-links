#include "queue.h"

Queue::Queue()
{
    count = 0;
}

Queue::Queue(const Queue& copy)
{
    data = copy.data;
    count = copy.count;
}

Queue::~Queue()
{
    
}

void Queue::insert(const int number)
{
    //cout << "Inserting " << number << "\n";
    data.push_back(number);
    count++;
}

int Queue::remove()
{
    int removeVal = data.front();
    
    if(isEmpty()) 
    {
        return 0;
    }    
    else
    {
        //cout << "Removing " << removeVal << "\n";
        data.erase(data.begin());
        count--;
        return removeVal;
    }
}

bool Queue::isFull() const
{
    return false;
}

bool Queue::isEmpty() const
{
    return data.empty();
}

int Queue::getCount() const
{
    return count;
}

void Queue::print() const
{
    cout << "\nPrinting queue...\n";
    
    for(size_t x = 0; x < data.size(); x++)
    {
        cout << data[x] << "\n";
    }
    
    cout << "\n";
}
