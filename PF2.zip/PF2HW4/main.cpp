#include <stdio.h>
#include <ctime>
#include "stack.h"
#include "queue.h"


void test_stack(Stack & testStack, int iterations)
{
    //Stack testing
    cout << "  ___   _                 _       _____             _     _               \n"                           
         << " / __| | |_   __ _   __  | |__   |_   _| ___   ___ | |_  (_)  _ _   __ _  \n"
         << " |__ | |  _| / _` | / _| | / /     | |  / -_) (_-< |  _| | | | ' | / _` | \n"
         << " |___/  |__| |__,_| |__| |_|_|     |_|  |___| /__/ |__|  |_| |_|_| |__, | \n"
         << "                                                                    |___/ \n\n";
    
    clock_t stackTime = clock();
    
    int randSeed = random() % 100;
    time_t now = time(NULL);
    srand(now + randSeed);
    int pushCount = 0, popCount = 0, skippedPop = 0;
    
    for(int x = 0; x < iterations; x++)
    {
        int pctChance = rand() % 1000;
        int randVal = rand() % 100;
        
        if(pctChance >= 0 && pctChance <= 509)
        {
            pushCount++;
            testStack.push(randVal);
        }
        else if(!testStack.isEmpty())
        {
            popCount++;
            testStack.pop();
        }
        else
        {
            skippedPop++;
        }
    }
    
    int stackCount = testStack.getCount();
    
    cout << "push #: " << pushCount 
         << "\npop #: " << popCount 
         << "\ntotal: " << pushCount + popCount 
         << "\npops while list is empty: " << skippedPop
         << "\ncount: " << stackCount << "\n";
    
    if(iterations <= 5000)
    {
        testStack.print();
    }
    
    
    clock_t stackTime2=clock();
    double stack_run_time = (stackTime2-stackTime)/(double)CLOCKS_PER_SEC;
    cout << "Stack run time: " << stack_run_time << " seconds\n\n";
}

void test_queue(Queue & testQueue, int iterations)
{
    //Queue testing
    cout << "   ___                                _____             _     _               \n"                           
         << "  / _ |   _  _   ___   _  _   ___    |_   _| ___   ___ | |_  (_)  _ _   __ _  \n"
         << " | (_) | | || | / -_) | || | / -_)     | |  / -_) (_-< |  _| | | | ' | / _` | \n"
         << "  |__|_|  |_,_| |___|  |_,_| |___|     |_|  |___| /__/ |__|  |_| |_|_| |__, | \n"
         << "                                                                         |___/ \n\n";
         
    clock_t queueTime = clock();
    
    int randSeed2 = random() % 100;
    time_t now2 = time(NULL);
    srand(now2 + randSeed2);
    int insertCount = 0, removeCount = 0, skippedRem = 0;
    
    for(int x = 0; x < iterations; x++)
    {
        int pctChance2 = rand() % 1000;
        int randVal2 = rand() % 100;
        
        if(pctChance2 >= 0 && pctChance2 <= 509)
        {
            insertCount++;
            testQueue.insert(randVal2);
        }
        else if(!testQueue.isEmpty())
        {
            removeCount++;
            testQueue.remove();
        }
        else
        {
            skippedRem++;
        }
    }
    
    int queueCount = testQueue.getCount();
    
    cout << "insert #: " << insertCount 
         << "\nremove #: " << removeCount 
         << "\ntotal: " << insertCount + removeCount 
         << "\nremoves while list is empty: " << skippedRem
         << "\ncount: " << queueCount << "\n";
         
    if(iterations <= 5000)
    {
        testQueue.print();
    }
    
    
    clock_t queueTime2 = clock();
    double queue_run_time = (queueTime2-queueTime)/(double)CLOCKS_PER_SEC;
    cout << "Queue run time: " << queue_run_time << " seconds\n";
}

int main()
{
    Stack testStack1, testStack2, testStack3, testStack4, testStack5;
    
    test_stack(testStack1, 100);
    test_stack(testStack2, 1000);
    test_stack(testStack3, 10000);
    test_stack(testStack4, 100000);
    test_stack(testStack5, 1000000);
    
    Queue testQueue1, testQueue2, testQueue3, testQueue4, testQueue5;
    
    test_queue(testQueue1, 100);
    test_queue(testQueue2, 1000);
    test_queue(testQueue3, 10000);
    test_queue(testQueue4, 100000);
    test_queue(testQueue5, 1000000);
    
    return 0;
}
