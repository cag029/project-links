#include "stack.h"

Stack::Stack()
{
    count = 0;
}

Stack::Stack(const Stack& copy)
{
    data = copy.data;
    count = copy.count;
}

Stack::~Stack()
{
    
}

void Stack::push(const int number)
{
    //cout << "Pushing " << number << "\n";
    data.push_back(number);
    count++;
}

int Stack::pop()
{
    int popVal = data.back();
    
    if(isEmpty())
    {
        return 0;
    }
    else
    {
        //cout << "Popping " << popVal << "\n";
        data.pop_back();
        count--;
    
        return popVal;
    }
}

int Stack::top() const
{
    if(isEmpty()) 
    {
        return 0;
    }
    
    return data.back();
}

bool Stack::isFull() const
{
    return false;
}

bool Stack::isEmpty() const
{
    return data.empty();
}

int Stack::getCount() const
{
    return count;
}

void Stack::print() const
{
    cout << "\nPrinting stack...\n";
    
    for(int x = data.size() - 1; x >= 0; x--)
    {
        cout << data[x] << "\n";
    }
    
    cout << "\n";
}
