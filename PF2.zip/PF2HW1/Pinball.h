#include <iostream>

using namespace std;

class Pinball
{
    public:
    
        Pinball();
        Pinball(const string NAME, const int PRODYEAR, const string MANUFACTURER, const float AVGFUNRATING, const string THEMES);
        Pinball(const Pinball & copy);
        ~Pinball();
        
        //get.
        string getName() const;
        int getProductionYear() const;
        string getManufacturer() const;
        float getAvgFunRating() const;
        string getThemes() const;
        
        //set.
        void setName(const string name);
        void setProductionYear(const int productionYear);
        void setManufacturer(const string manufacturer);
        void setAvgFunRating(const float avgFunRating);
        void setThemes(const string themes);
        void setAttributes(const string NAME, const int PRODYEAR, const string MANUFACTURER, const float AVGFUNRATING, const string THEMES);
        
        //misc. methods
        void print() const;
        
    private:
        string name;
        int productionYear;
        string manufacturer;
        float avgFunRating;
        string themes;
};
