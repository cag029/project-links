#include "Pinball.h"

Pinball::Pinball()
{
    name = "null";
    productionYear = 0;
    manufacturer = "null";
    avgFunRating = 0.0;
    themes = "null";
}

Pinball::Pinball(const string NAME, const int PRODYEAR, const string MANUFACTURER, const float AVGFUNRATING, const string THEMES)
{
    name = NAME;
    productionYear = PRODYEAR;
    manufacturer = MANUFACTURER;
    avgFunRating = AVGFUNRATING;
    themes = THEMES;
}

Pinball::Pinball(const Pinball & copy)
{
    name = copy.name;
    productionYear = copy.productionYear;
    manufacturer = copy.manufacturer;
    avgFunRating = copy.avgFunRating;
    themes = copy.themes;
}

Pinball::~Pinball()
{
    
}

string Pinball::getName() const
{
    return name;
}

int Pinball::getProductionYear() const
{
    return productionYear;
}

string Pinball::getManufacturer() const
{
    return manufacturer;
}

float Pinball::getAvgFunRating() const
{
    return avgFunRating;
}

string Pinball::getThemes() const
{
    return themes;
}

void Pinball::setName(const string NAME)
{
    name = NAME;
}

void Pinball::setProductionYear(const int PRODYEAR)
{
    productionYear = PRODYEAR;
}

void Pinball::setManufacturer(const string MANUFACTURER)
{
    manufacturer = MANUFACTURER;
}

void Pinball::setAvgFunRating(const float AVGFUNRATING)
{
    avgFunRating = AVGFUNRATING;
}

void Pinball::setThemes(const string THEMES)
{
    themes = THEMES;
}

void Pinball::setAttributes(const string NAME, const int PRODYEAR, const string MANUFACTURER, const float AVGFUNRATING, const string THEMES)
{
    name = NAME;
    productionYear = PRODYEAR;
    manufacturer = MANUFACTURER;
    avgFunRating = AVGFUNRATING;
    themes = THEMES;
}

void Pinball::print() const
{
    cout << name << endl << productionYear << endl << manufacturer << endl << avgFunRating << endl << themes << endl;
}
