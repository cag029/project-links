#include "Pinball.h"
#include <fstream>
#include <iostream>

const int size = 10;
int currentMachine = 0;

void readFile(string fileName, Pinball pinballMachines[size])
{
    currentMachine = 0;
    
    ifstream pinballIn;
    pinballIn.open(fileName);
    
    string name, productionYearString, manufacturer, avgFunRatingString, themes;
    int productionYear;
    float avgFunRating;
    
    while(!pinballIn.eof())
    {
        getline(pinballIn, name, ',');
        getline(pinballIn, productionYearString, ',');
        getline(pinballIn, manufacturer, ',');
        getline(pinballIn, avgFunRatingString, ',');
        getline(pinballIn, themes, '.');
            
        productionYear = stoi(productionYearString);
        avgFunRating = stof(avgFunRatingString);
                
        if(!pinballIn.eof())
        {
            Pinball currMachine = Pinball(name, productionYear, manufacturer, avgFunRating, themes);
            pinballMachines[currentMachine] = currMachine;
            currentMachine++;
        }
        else
        {
            //cout << "End of file.";
        }
    }
    
    pinballIn.close();
}

void writeFile(string fileName, Pinball pinballMachines[size])
{
    ofstream pinballOut;
    pinballOut.open(fileName);
    
    for(int x = 0; x < size; x++)
    {
        if(pinballMachines[x].getName() != "null")
        {
            pinballOut  << pinballMachines[x].getName() << ", " 
                    << pinballMachines[x].getProductionYear() << ","
                    << pinballMachines[x].getManufacturer() << ", "
                    << pinballMachines[x].getAvgFunRating() << ","
                    << pinballMachines[x].getThemes() << ".";
        }
        /*else
        {
            pinballOut  << "\n" << pinballMachines[x].getName() << ", " 
                        << pinballMachines[x].getProductionYear() << ","
                        << pinballMachines[x].getManufacturer() << ", "
                        << pinballMachines[x].getAvgFunRating() << ","
                        << pinballMachines[x].getThemes() << ".";
        }*/
    }
    
    pinballOut.close();
}

void printGraphic()
{
    cout << "   ___  _      __        ____        ______                    \n";  
    cout << "  / _ |(_)__  / /  ___ _/ / / ____  / __/ /____  _______ ____  \n";
    cout << " / ___/ / _ |/ _ |/ _ `/ / / /___/ _| |/ __/ _ |/ __/ -_) __/  \n";
    cout << "/_/  /_/_//_/_.__/|_,_/_/_/       /___/|__/|___/_/  |__/_/     \n\n";

    cout << "                  ___  ___  ___  ___  \n";
    cout << "                 / _ |/ _ |/ _ |/ _ | \n";
    cout << "                 |_, / // / // / // / \n";
    cout << "                /___/|___/|___/|___/ \n\n";
    
    cout << "Welcome to Pinball-Storer 9000! \n\n";
    
    cout << "Please choose from the following options: \n";
}

void printMenu()
{
    cout << "(1) - Load machines from \"pinball.txt\" \n    *Note that this will clear any unsaved machines you may have entered.\n";
    cout << "(2) - Insert a machine into the array of machines \n";
    cout << "(3) - Save the array to \"pinball.txt\" and continue using Pinball-Storer 9000! \n";
    cout << "(4) - Print the name and manufacturer of machines of a specified year \n";
    cout << "(5) - Print information for all machines in the array \n";
    cout << "(6) - Quit and save the array back to \"pinball.txt\" \n";
    cout << "(7) - Quit without saving, in case you have any issues. \n\n";
}

void addMachine(Pinball pinballMachines[size])
{
    //currentMachine++;
    
    string name, productionYearString, manufacturer, avgFunRatingString, themes;
    int productionYear;
    float avgFunRating;
    bool machineStored = false;
    
    cout << "Please input machine attributes in the following format: \n";
    cout << "name,production year,manufacturer,average rating,theme1, theme2. \n\n";
    cout << "For example: Aerosmith,2017,Stern Pinball,8.1,Celebrities, Licensed theme, Music. \n";
    cout << "   *Note there are no spaces, except for between themes which are \n   followed by a period. Production year is a whole number, and rating \n   is a decimal number or a whole number. \n\n";
    
    getline(cin, name, ',');
    getline(cin, productionYearString, ',');
    getline(cin, manufacturer, ',');
    getline(cin, avgFunRatingString, ',');
    getline(cin, themes, '.');
        
    productionYear = stoi(productionYearString);
    avgFunRating = stof(avgFunRatingString);
    
    for(int x = 0; x < size; x++)
    {
        if(pinballMachines[x].getName() == "null" && !machineStored)
        {
            currentMachine = x;
            Pinball machineToStore = Pinball(name, productionYear, manufacturer, avgFunRating, themes);
            pinballMachines[currentMachine] = machineToStore;
            machineStored = true;
            currentMachine++;
        }
    }
    cout << name << "\n\nHas been stored, please choose another option below.\n\n";
}

void findMachineByYear(int year, Pinball pinballMachines[size])
{
    string currentName, currentManufacturer;
    
    for(int x = 0; x < size; x++)
    {
        if(pinballMachines[x].getProductionYear() == year)
        {
            currentName = pinballMachines[x].getName();
            currentManufacturer = pinballMachines[x].getManufacturer();
            cout << currentName << "\n" << currentManufacturer<< "\n\n";
        }
    }
}

int main()
{
    Pinball pinballMachines[size];
    int choice;
    int yearToFind;
    bool run = true;
    
    printGraphic();
    printMenu();
    
    while(run)
    {
        cin >> choice;
        cout << endl;
        
        switch(choice)
        {
            case 1:
            
                for(int x = 0; x < size; x++)
                {
                    Pinball tempClear = Pinball();
                    pinballMachines[x] = tempClear;
                }
            
                readFile("pinball.txt", pinballMachines);
                cout << "You have stored the machines from \"pinball.txt\" in the \narray of machines, please choose another option below. \n\n";
                printMenu();
                break;
            case 2:
                addMachine(pinballMachines);
                printMenu();
                break;
            case 3:
                cout << "You have saved the array to \"pinball.txt\". Please choose another option below. \n\n";
                printMenu();
                writeFile("pinball.txt", pinballMachines);
                break;
            case 4:
                cout << "Please enter a year to find machines manufactured during that year: \n";
                cin >> yearToFind;
                findMachineByYear(yearToFind, pinballMachines);
                cout << "\nThe machine names and manufacturers for machines from " << yearToFind << " are displayed above. \n";
                cout << "Please choose another option below. \n\n";
                printMenu();
                break;
            case 5:
                cout << "You have chosen to display all attributes for all machines stored in the array: \n\n";
                
                for(int x = 0; x < size; x++)
                {
                    //cout << "Machine " << x + 1 << "\n";
                    pinballMachines[x].print();
                    cout << endl;
                }
                
                cout << "Please choose another option below. \n\n";
                printMenu();
                break;
            case 6:
                cout << "You have chosen to exit, and your array has been saved to \"pinball.txt\". \n";
                cout << "Thank you for using Pinball-Storer 9000! \n";
                writeFile("pinball.txt", pinballMachines);
                run = false;
                break;
            case 7:
                cout << "You have chosen to exit without saving. \n";
                cout << "   *Note if you have previously saved with option 3, any changes you \n    made before saving will be there but changes made after will not.\n";
                cout << "Thank you for using Pinball-Storer 9000! \n";
                run = false;
                break;
            default:
                cout << "Invalid input, please input a number from 1 to 7. \n\n";
                break;
        }
    }
    
    return 0;
}
