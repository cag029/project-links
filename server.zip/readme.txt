--port forwarding--

1. open your browser
2. in one tab search 'whats my IP' in google and copy the public IP address
3. in another tab
	- navigate to 192.168.1.1 (or 192.168.0.1 if that doesnt work)
	- log in using the user/password on your router
	- find port forwarding settings and set a new rule
		- open a command prompt and type "ipconfig" and look for "ethernet adapter ethernet" 
		  and then find the IPv4 address (should look like 192.168.x.x)
		- in local port/IP set the IP address to that IPv4 address
		- select TCP as the protocol
		- set any port start/end values to 8000
		- set the remote IP to "All IP addresses"
	- hit apply
4. turn off windows defender by searching windows defender in the windows search bar, select turn windows defnder on/off, and turn off windows defender for both




--to start the server on the machine--

first install python3 here: https://www.python.org/downloads/

1. open your file explorer and navigate to your C:/ drive
	- create two folders 'Storage' and 'Program'
2. unzip the zip file into the 'Program' folder
3. open a command prompt
	- type 'cd C:\Program' and hit enter
	- type 'pip install -r requirements.txt' and hit enter
	- type 'python app.py' and hit enter

(if you ever need to restart the server, i.e. turn off the machine, you just need to open a command prompt and type 'cd C:\Program' and hit enter, then type 'python app.py' and hit enter)




--upload/download files--

1. open your browser
2. paste this link: http://your_IP_here:8000 (your public IP from step 2 of port forwarding)
3: login credentials
	- Username: test
	- Password: test
