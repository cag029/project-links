from flask import Flask, request, send_from_directory, render_template_string
import os
from functools import wraps

app = Flask(__name__)
UPLOAD_FOLDER = "C:/Storage"
USERNAME = "test"  # username
PASSWORD = "test"  # password
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>

<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('table').DataTable();
    });
</script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f4f4f4; }
        tr:hover { background-color: #f9f9f9; }
        form { display: inline; }
        button { background-color: #007BFF; color: white; border: none; padding: 5px 10px; cursor: pointer; }
        button:hover { background-color: #0056b3; }
    </style>
</head>
<body>
    <form action="/upload" method="post" enctype="multipart/form-data">
        <input type="file" name="file" required>
        <button type="submit">Upload</button>
    </form>
    <table>
    <thead>
        <tr>
            <th>Filename</th>
            <th>Size (KB)</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        {% for file, size in files %}
        <tr>
            <td>{{ file }}</td>
            <td>{{ size }}</td>
            <td>
                <form action="/download/{{ file }}" method="get" style="display: inline;">
                    <button type="submit">Download</button>
                </form>
                <form action="/delete/{{ file }}" method="post" style="display: inline;">
                    <button type="submit">Delete</button>
                </form>
            </td>
        </tr>
        {% endfor %}
    </tbody>
</table>
</body>
</html>
"""

# Authentication decorator
def check_auth(username, password):
    return username == USERNAME and password == PASSWORD

def authenticate():
    return "Access denied", 401, {"WWW-Authenticate": 'Basic realm="Login Required"'}

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated

@app.route("/")
@requires_auth
def index():
    files = [
        (f, round(os.path.getsize(os.path.join(UPLOAD_FOLDER, f)) / 1024, 2))
        for f in os.listdir(UPLOAD_FOLDER)
    ]
    return render_template_string(HTML_TEMPLATE, files=files)


@app.route("/upload", methods=["POST"])
@requires_auth
def upload_file():
    file = request.files['file']
    file.save(os.path.join(UPLOAD_FOLDER, file.filename))
    return "File uploaded successfully! <a href='/'>Back</a>"

@app.route("/download/<filename>", methods=["GET"])
@requires_auth
def download_file(filename):
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(filepath):
        return send_from_directory(filepath, as_attachment=True)
    else:
        return f"Error: {filename} does not exist.", 404

@app.route("/delete/<path:filename>", methods=["POST"])
@requires_auth
def delete_file(filename):
    os.remove(os.path.join(UPLOAD_FOLDER, filename))
    return "File deleted successfully! <a href='/'>Back</a>"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
